"use strict";

class Evento {
    // Completa la clase con su constructor y métodos
}
