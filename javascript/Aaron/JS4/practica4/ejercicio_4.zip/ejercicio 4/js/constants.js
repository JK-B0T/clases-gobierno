'use strict';

// Constantes globales aquí
